from setuptools import find_packages, setup



setup(
    name="Attention in cv",
    version="0.0.1",
    author="mohamed ahmed",
    author_email="engmohamedelshrbeny@gmail.com",
    description=(
        "Attention CV Codebase For Attention,Backbone, MLP, Convolution"
    ),
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    keywords=(
        "Attention"
        "Backbone"
    ),
    license="Apache",
    url="https://github.com/moh2236945/attention-in-cv",
    package_dir={"": "."},
    packages=find_packages("."),
    # entry_points={
    #     "console_scripts": [
    #         "huggingface-cli=huggingface_hub.commands.huggingface_cli:main"
    #     ]
    # },
    python_requires=">=3.7.0",
    # install_requires=install_requires,
    classifiers=[
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)